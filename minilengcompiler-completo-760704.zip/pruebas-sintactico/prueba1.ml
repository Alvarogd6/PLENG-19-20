%--------------------------------------------------------
Programa identificador;
%--------------------------------------------------------

entero caracter, error;

%--------------------------------------------------------
Principio
%--------------------------------------------------------
        n := 0;
        caracter ent, si_no;

        escribir("Errores debido a identificadores con el nombre de palabras reservadas");

        booleano principio;
        
        Si principio ent
                n := n - 6;
        si_no
                n := m - 27;
        FSi

        y:="principio";

Fin
