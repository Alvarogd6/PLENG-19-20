%------------------------------------------------------
programa comillas;
%------------------------------------------------------
	
%------------------------------------------------------
principio
%------------------------------------------------------
	escribir("Siguiente linea dara fallo debido a la comilla simple");
	escribir('Aqui peta");
	escribir("Aqui no llega");
fin

