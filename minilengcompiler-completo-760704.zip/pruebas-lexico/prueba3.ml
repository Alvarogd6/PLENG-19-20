%------------------------------------------------------
programa caracter_no_identificado;
%------------------------------------------------------

	caracter f;
	
%------------------------------------------------------
principio
%------------------------------------------------------
	f := "¡";
    escribir("¡");
	escribir("Siguiente linea dara fallo debido a ¡");
	escribir(¡);
	escribir("ERROR LEXICO");
fin

